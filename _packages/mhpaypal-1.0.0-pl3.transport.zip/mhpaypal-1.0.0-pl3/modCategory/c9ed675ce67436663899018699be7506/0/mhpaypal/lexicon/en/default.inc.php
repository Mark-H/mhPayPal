<?php

$_lang['mhpaypal'] = 'mhPayPal';
$_lang['mhpaypal.desc'] = 'mhPayPal is a wicked addon that will do something for you, real easy!';

?>
