+++++++++++++++++++++++++++++++++++
++                               ++
++   mhPayPal                   ++
++   Developer:  Your Name       ++
++   License:    GPL GNU v2      ++
++                               ++
+++++++++++++++++++++++++++++++++++


mhPayPal is a wicked addon that will do something for you, real easy!


Documentation: 		http://rtfm.modx.com/display/ADDON/mhPayPal
Bugs & Features: 	https://github.com/DevName/mhPayPal/issues
Commercial Support:	mhpaypal@developer.com
