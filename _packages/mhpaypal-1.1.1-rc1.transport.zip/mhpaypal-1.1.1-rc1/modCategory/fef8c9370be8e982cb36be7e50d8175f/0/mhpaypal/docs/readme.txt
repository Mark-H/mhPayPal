++  mhPayPal 1.1.1-rc1
++  Developer:  Mark Hamstra, hello@markhamstra.com
++  License:    GNU GPL v2
++++++++++++++++++++++++++++++++++++++++++++++++++++

mhPayPal is a simple to use snippet which enables you
of receiving donations or (single product) payments.

It is inspired by FormIt and has three different hooks
which can be used to extend its basic functionality to
virtually anything, by the use of snippets or the included
hooks.

Please review the documentation for instructions on how
to set it up.

Documentation: 		http://rtfm.modx.com/display/ADDON/mhPayPal
Source Code:        https://github.com/Mark-H/mhPayPal
Bugs & Features: 	https://github.com/Mark-H/mhPayPal/issues
