<?php

$_lang['mhpaypal'] = 'mhPayPal';

$_lang['validation.fieldrequired'] = 'This field is required.';
$_lang['validation.amount.notnumeric'] = 'The amount specified is not a valid numeric value.';
$_lang['validation.amount.lessthanmin'] = 'Sorry, the minimum amount we can accept is [[+min]].';
$_lang['validation.currency.notallowed'] = 'Sorry, we can\'t accept that currency. We do accept the following: [[+currencies]].';

$_lang['error.message'] = '[[+key]]: [[+error]]';

?>
